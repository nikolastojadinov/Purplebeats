import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertLikedSongSchema, insertPlaylistSchema, insertPlaylistSongSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Artists
  app.get("/api/artists", async (req, res) => {
    try {
      const artists = await storage.getArtists();
      res.json(artists);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch artists" });
    }
  });

  app.get("/api/artists/:id", async (req, res) => {
    try {
      const artist = await storage.getArtist(req.params.id);
      if (!artist) {
        return res.status(404).json({ message: "Artist not found" });
      }
      res.json(artist);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch artist" });
    }
  });

  // Albums
  app.get("/api/albums", async (req, res) => {
    try {
      const albums = await storage.getAlbums();
      res.json(albums);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch albums" });
    }
  });

  app.get("/api/albums/:id", async (req, res) => {
    try {
      const album = await storage.getAlbum(req.params.id);
      if (!album) {
        return res.status(404).json({ message: "Album not found" });
      }
      res.json(album);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch album" });
    }
  });

  // Songs
  app.get("/api/songs", async (req, res) => {
    try {
      const songs = await storage.getSongs();
      res.json(songs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch songs" });
    }
  });

  app.get("/api/songs/:id", async (req, res) => {
    try {
      const song = await storage.getSong(req.params.id);
      if (!song) {
        return res.status(404).json({ message: "Song not found" });
      }
      res.json(song);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch song" });
    }
  });

  app.get("/api/songs/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Query parameter 'q' is required" });
      }
      const songs = await storage.searchSongs(query);
      res.json(songs);
    } catch (error) {
      res.status(500).json({ message: "Failed to search songs" });
    }
  });

  app.get("/api/songs/recently-played", async (req, res) => {
    try {
      const songs = await storage.getRecentlyPlayed();
      res.json(songs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recently played songs" });
    }
  });

  app.get("/api/songs/trending", async (req, res) => {
    try {
      const songs = await storage.getTrendingSongs();
      res.json(songs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch trending songs" });
    }
  });

  app.post("/api/songs/:id/play", async (req, res) => {
    try {
      await storage.incrementPlayCount(req.params.id);
      res.json({ message: "Play count incremented" });
    } catch (error) {
      res.status(500).json({ message: "Failed to increment play count" });
    }
  });

  // Playlists
  app.get("/api/playlists", async (req, res) => {
    try {
      const playlists = await storage.getPlaylists();
      res.json(playlists);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch playlists" });
    }
  });

  app.get("/api/playlists/:id", async (req, res) => {
    try {
      const playlist = await storage.getPlaylistWithSongs(req.params.id);
      if (!playlist) {
        return res.status(404).json({ message: "Playlist not found" });
      }
      res.json(playlist);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch playlist" });
    }
  });

  app.post("/api/playlists", async (req, res) => {
    try {
      const validatedData = insertPlaylistSchema.parse(req.body);
      const playlist = await storage.createPlaylist(validatedData);
      res.status(201).json(playlist);
    } catch (error) {
      res.status(400).json({ message: "Invalid playlist data" });
    }
  });

  app.post("/api/playlists/:id/songs", async (req, res) => {
    try {
      const playlistId = req.params.id;
      const validatedData = insertPlaylistSongSchema.parse({
        ...req.body,
        playlistId,
      });
      const playlistSong = await storage.addSongToPlaylist(validatedData);
      res.status(201).json(playlistSong);
    } catch (error) {
      res.status(400).json({ message: "Invalid playlist song data" });
    }
  });

  app.delete("/api/playlists/:playlistId/songs/:songId", async (req, res) => {
    try {
      await storage.removeSongFromPlaylist(req.params.playlistId, req.params.songId);
      res.json({ message: "Song removed from playlist" });
    } catch (error) {
      res.status(500).json({ message: "Failed to remove song from playlist" });
    }
  });

  // Liked Songs
  app.get("/api/liked-songs", async (req, res) => {
    try {
      const songs = await storage.getLikedSongs();
      res.json(songs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch liked songs" });
    }
  });

  app.post("/api/liked-songs", async (req, res) => {
    try {
      const validatedData = insertLikedSongSchema.parse(req.body);
      const likedSong = await storage.likeSong(validatedData);
      res.status(201).json(likedSong);
    } catch (error) {
      res.status(400).json({ message: "Invalid liked song data" });
    }
  });

  app.delete("/api/liked-songs/:songId", async (req, res) => {
    try {
      await storage.unlikeSong(req.params.songId);
      res.json({ message: "Song unliked" });
    } catch (error) {
      res.status(500).json({ message: "Failed to unlike song" });
    }
  });

  app.get("/api/liked-songs/:songId/check", async (req, res) => {
    try {
      const isLiked = await storage.isSongLiked(req.params.songId);
      res.json({ isLiked });
    } catch (error) {
      res.status(500).json({ message: "Failed to check if song is liked" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
