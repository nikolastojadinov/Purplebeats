import { 
  type Artist, type Album, type Song, type Playlist, type PlaylistSong, type LikedSong,
  type InsertArtist, type InsertAlbum, type InsertSong, type InsertPlaylist, type InsertPlaylistSong, type InsertLikedSong,
  type SongWithDetails, type AlbumWithDetails, type PlaylistWithDetails
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Artists
  getArtists(): Promise<Artist[]>;
  getArtist(id: string): Promise<Artist | undefined>;
  createArtist(artist: InsertArtist): Promise<Artist>;

  // Albums
  getAlbums(): Promise<Album[]>;
  getAlbum(id: string): Promise<Album | undefined>;
  getAlbumsByArtist(artistId: string): Promise<Album[]>;
  createAlbum(album: InsertAlbum): Promise<Album>;

  // Songs
  getSongs(): Promise<Song[]>;
  getSong(id: string): Promise<Song | undefined>;
  getSongsByAlbum(albumId: string): Promise<Song[]>;
  getSongsByArtist(artistId: string): Promise<Song[]>;
  searchSongs(query: string): Promise<SongWithDetails[]>;
  getRecentlyPlayed(): Promise<SongWithDetails[]>;
  getTrendingSongs(): Promise<SongWithDetails[]>;
  createSong(song: InsertSong): Promise<Song>;
  incrementPlayCount(songId: string): Promise<void>;

  // Playlists
  getPlaylists(): Promise<Playlist[]>;
  getPlaylist(id: string): Promise<Playlist | undefined>;
  getPlaylistWithSongs(id: string): Promise<PlaylistWithDetails | undefined>;
  createPlaylist(playlist: InsertPlaylist): Promise<Playlist>;
  addSongToPlaylist(data: InsertPlaylistSong): Promise<PlaylistSong>;
  removeSongFromPlaylist(playlistId: string, songId: string): Promise<void>;

  // Liked Songs
  getLikedSongs(): Promise<SongWithDetails[]>;
  likeSong(data: InsertLikedSong): Promise<LikedSong>;
  unlikeSong(songId: string): Promise<void>;
  isSongLiked(songId: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private artists: Map<string, Artist> = new Map();
  private albums: Map<string, Album> = new Map();
  private songs: Map<string, Song> = new Map();
  private playlists: Map<string, Playlist> = new Map();
  private playlistSongs: Map<string, PlaylistSong> = new Map();
  private likedSongs: Map<string, LikedSong> = new Map();

  constructor() {
    this.seedData();
  }

  private seedData() {
    // Create sample artists
    const artist1: Artist = {
      id: "artist-1",
      name: "Synthwave Collective",
      imageUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      bio: "Electronic music collective specializing in synthwave and retrowave",
      createdAt: new Date(),
    };

    const artist2: Artist = {
      id: "artist-2",
      name: "MC Purple Gold",
      imageUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      bio: "Hip hop artist known for urban beats and lyrical prowess",
      createdAt: new Date(),
    };

    const artist3: Artist = {
      id: "artist-3",
      name: "The Violet Sounds",
      imageUrl: "https://images.unsplash.com/photo-1487180144351-b8472da7d491?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      bio: "Indie rock band with dreamy purple-hued soundscapes",
      createdAt: new Date(),
    };

    this.artists.set(artist1.id, artist1);
    this.artists.set(artist2.id, artist2);
    this.artists.set(artist3.id, artist3);

    // Create sample albums
    const album1: Album = {
      id: "album-1",
      title: "Electronic Vibes",
      artistId: artist1.id,
      imageUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      releaseDate: new Date("2024-01-15"),
      genre: "Electronic",
      createdAt: new Date(),
    };

    const album2: Album = {
      id: "album-2",
      title: "Urban Beats",
      artistId: artist2.id,
      imageUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      releaseDate: new Date("2024-02-20"),
      genre: "Hip Hop",
      createdAt: new Date(),
    };

    const album3: Album = {
      id: "album-3",
      title: "Indie Dreams",
      artistId: artist3.id,
      imageUrl: "https://images.unsplash.com/photo-1487180144351-b8472da7d491?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300",
      releaseDate: new Date("2024-03-10"),
      genre: "Indie Rock",
      createdAt: new Date(),
    };

    this.albums.set(album1.id, album1);
    this.albums.set(album2.id, album2);
    this.albums.set(album3.id, album3);

    // Create sample songs
    const songs: Song[] = [
      {
        id: "song-1",
        title: "Midnight Pulse",
        artistId: artist1.id,
        albumId: album1.id,
        duration: 272, // 4:32
        audioUrl: "https://www.soundjay.com/misc/sounds/bell-ringing-05.wav",
        imageUrl: album1.imageUrl,
        genre: "Electronic",
        playCount: 1250000,
        createdAt: new Date(),
      },
      {
        id: "song-2",
        title: "Neon Nights",
        artistId: artist1.id,
        albumId: album1.id,
        duration: 195, // 3:15
        audioUrl: "https://www.soundjay.com/misc/sounds/bell-ringing-05.wav",
        imageUrl: album1.imageUrl,
        genre: "Electronic",
        playCount: 980000,
        createdAt: new Date(),
      },
      {
        id: "song-3",
        title: "Street Dreams",
        artistId: artist2.id,
        albumId: album2.id,
        duration: 228, // 3:48
        audioUrl: "https://www.soundjay.com/misc/sounds/bell-ringing-05.wav",
        imageUrl: album2.imageUrl,
        genre: "Hip Hop",
        playCount: 2100000,
        createdAt: new Date(),
      },
      {
        id: "song-4",
        title: "Golden Hour",
        artistId: artist3.id,
        albumId: album3.id,
        duration: 205, // 3:25
        audioUrl: "https://www.soundjay.com/misc/sounds/bell-ringing-05.wav",
        imageUrl: album3.imageUrl,
        genre: "Indie Rock",
        playCount: 1750000,
        createdAt: new Date(),
      },
      {
        id: "song-5",
        title: "Purple Haze Dreams",
        artistId: artist3.id,
        albumId: album3.id,
        duration: 312, // 5:12
        audioUrl: "https://www.soundjay.com/misc/sounds/bell-ringing-05.wav",
        imageUrl: album3.imageUrl,
        genre: "Indie Rock",
        playCount: 890000,
        createdAt: new Date(),
      },
    ];

    songs.forEach(song => this.songs.set(song.id, song));

    // Create sample playlists
    const playlist1: Playlist = {
      id: "playlist-1",
      name: "Daily Mix 1",
      description: "Your daily dose of favorites",
      imageUrl: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      isPublic: true,
      songCount: 3,
      createdAt: new Date(),
    };

    const playlist2: Playlist = {
      id: "playlist-2",
      name: "Discover Weekly",
      description: "Fresh finds for you",
      imageUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&h=150",
      isPublic: true,
      songCount: 2,
      createdAt: new Date(),
    };

    this.playlists.set(playlist1.id, playlist1);
    this.playlists.set(playlist2.id, playlist2);

    // Add songs to playlists
    const playlistSong1: PlaylistSong = {
      id: "ps-1",
      playlistId: playlist1.id,
      songId: "song-1",
      position: 1,
      addedAt: new Date(),
    };

    const playlistSong2: PlaylistSong = {
      id: "ps-2",
      playlistId: playlist1.id,
      songId: "song-3",
      position: 2,
      addedAt: new Date(),
    };

    this.playlistSongs.set(playlistSong1.id, playlistSong1);
    this.playlistSongs.set(playlistSong2.id, playlistSong2);
  }

  // Artists
  async getArtists(): Promise<Artist[]> {
    return Array.from(this.artists.values());
  }

  async getArtist(id: string): Promise<Artist | undefined> {
    return this.artists.get(id);
  }

  async createArtist(insertArtist: InsertArtist): Promise<Artist> {
    const id = randomUUID();
    const artist: Artist = { ...insertArtist, id, createdAt: new Date() };
    this.artists.set(id, artist);
    return artist;
  }

  // Albums
  async getAlbums(): Promise<Album[]> {
    return Array.from(this.albums.values());
  }

  async getAlbum(id: string): Promise<Album | undefined> {
    return this.albums.get(id);
  }

  async getAlbumsByArtist(artistId: string): Promise<Album[]> {
    return Array.from(this.albums.values()).filter(album => album.artistId === artistId);
  }

  async createAlbum(insertAlbum: InsertAlbum): Promise<Album> {
    const id = randomUUID();
    const album: Album = { ...insertAlbum, id, createdAt: new Date() };
    this.albums.set(id, album);
    return album;
  }

  // Songs
  async getSongs(): Promise<Song[]> {
    return Array.from(this.songs.values());
  }

  async getSong(id: string): Promise<Song | undefined> {
    return this.songs.get(id);
  }

  async getSongsByAlbum(albumId: string): Promise<Song[]> {
    return Array.from(this.songs.values()).filter(song => song.albumId === albumId);
  }

  async getSongsByArtist(artistId: string): Promise<Song[]> {
    return Array.from(this.songs.values()).filter(song => song.artistId === artistId);
  }

  async searchSongs(query: string): Promise<SongWithDetails[]> {
    const songs = Array.from(this.songs.values()).filter(song => 
      song.title.toLowerCase().includes(query.toLowerCase())
    );
    
    return Promise.all(songs.map(async song => {
      const artist = await this.getArtist(song.artistId);
      const album = song.albumId ? await this.getAlbum(song.albumId) : undefined;
      const isLiked = await this.isSongLiked(song.id);
      
      return {
        ...song,
        artist: artist!,
        album,
        isLiked,
      };
    }));
  }

  async getRecentlyPlayed(): Promise<SongWithDetails[]> {
    const songs = Array.from(this.songs.values()).slice(0, 5);
    
    return Promise.all(songs.map(async song => {
      const artist = await this.getArtist(song.artistId);
      const album = song.albumId ? await this.getAlbum(song.albumId) : undefined;
      const isLiked = await this.isSongLiked(song.id);
      
      return {
        ...song,
        artist: artist!,
        album,
        isLiked,
      };
    }));
  }

  async getTrendingSongs(): Promise<SongWithDetails[]> {
    const songs = Array.from(this.songs.values())
      .sort((a, b) => (b.playCount || 0) - (a.playCount || 0))
      .slice(0, 10);
    
    return Promise.all(songs.map(async song => {
      const artist = await this.getArtist(song.artistId);
      const album = song.albumId ? await this.getAlbum(song.albumId) : undefined;
      const isLiked = await this.isSongLiked(song.id);
      
      return {
        ...song,
        artist: artist!,
        album,
        isLiked,
      };
    }));
  }

  async createSong(insertSong: InsertSong): Promise<Song> {
    const id = randomUUID();
    const song: Song = { ...insertSong, id, playCount: 0, createdAt: new Date() };
    this.songs.set(id, song);
    return song;
  }

  async incrementPlayCount(songId: string): Promise<void> {
    const song = this.songs.get(songId);
    if (song) {
      const updatedSong = { ...song, playCount: (song.playCount || 0) + 1 };
      this.songs.set(songId, updatedSong);
    }
  }

  // Playlists
  async getPlaylists(): Promise<Playlist[]> {
    return Array.from(this.playlists.values());
  }

  async getPlaylist(id: string): Promise<Playlist | undefined> {
    return this.playlists.get(id);
  }

  async getPlaylistWithSongs(id: string): Promise<PlaylistWithDetails | undefined> {
    const playlist = await this.getPlaylist(id);
    if (!playlist) return undefined;

    const playlistSongs = Array.from(this.playlistSongs.values())
      .filter(ps => ps.playlistId === id)
      .sort((a, b) => a.position - b.position);

    const songs = await Promise.all(playlistSongs.map(async ps => {
      const song = await this.getSong(ps.songId);
      if (!song) return null;
      
      const artist = await this.getArtist(song.artistId);
      const album = song.albumId ? await this.getAlbum(song.albumId) : undefined;
      const isLiked = await this.isSongLiked(song.id);
      
      return {
        ...song,
        artist: artist!,
        album,
        isLiked,
      };
    }));

    return {
      ...playlist,
      songs: songs.filter(Boolean) as SongWithDetails[],
    };
  }

  async createPlaylist(insertPlaylist: InsertPlaylist): Promise<Playlist> {
    const id = randomUUID();
    const playlist: Playlist = { ...insertPlaylist, id, songCount: 0, createdAt: new Date() };
    this.playlists.set(id, playlist);
    return playlist;
  }

  async addSongToPlaylist(data: InsertPlaylistSong): Promise<PlaylistSong> {
    const id = randomUUID();
    const playlistSong: PlaylistSong = { ...data, id, addedAt: new Date() };
    this.playlistSongs.set(id, playlistSong);

    // Update playlist song count
    const playlist = this.playlists.get(data.playlistId);
    if (playlist) {
      const updatedPlaylist = { ...playlist, songCount: playlist.songCount + 1 };
      this.playlists.set(data.playlistId, updatedPlaylist);
    }

    return playlistSong;
  }

  async removeSongFromPlaylist(playlistId: string, songId: string): Promise<void> {
    const playlistSong = Array.from(this.playlistSongs.values())
      .find(ps => ps.playlistId === playlistId && ps.songId === songId);
    
    if (playlistSong) {
      this.playlistSongs.delete(playlistSong.id);

      // Update playlist song count
      const playlist = this.playlists.get(playlistId);
      if (playlist) {
        const updatedPlaylist = { ...playlist, songCount: Math.max(0, playlist.songCount - 1) };
        this.playlists.set(playlistId, updatedPlaylist);
      }
    }
  }

  // Liked Songs
  async getLikedSongs(): Promise<SongWithDetails[]> {
    const likedSongs = Array.from(this.likedSongs.values());
    
    return Promise.all(likedSongs.map(async liked => {
      const song = await this.getSong(liked.songId);
      if (!song) return null;
      
      const artist = await this.getArtist(song.artistId);
      const album = song.albumId ? await this.getAlbum(song.albumId) : undefined;
      
      return {
        ...song,
        artist: artist!,
        album,
        isLiked: true,
      };
    })).then(songs => songs.filter(Boolean) as SongWithDetails[]);
  }

  async likeSong(data: InsertLikedSong): Promise<LikedSong> {
    const id = randomUUID();
    const likedSong: LikedSong = { ...data, id, likedAt: new Date() };
    this.likedSongs.set(id, likedSong);
    return likedSong;
  }

  async unlikeSong(songId: string): Promise<void> {
    const likedSong = Array.from(this.likedSongs.values()).find(ls => ls.songId === songId);
    if (likedSong) {
      this.likedSongs.delete(likedSong.id);
    }
  }

  async isSongLiked(songId: string): Promise<boolean> {
    return Array.from(this.likedSongs.values()).some(ls => ls.songId === songId);
  }
}

export const storage = new MemStorage();
