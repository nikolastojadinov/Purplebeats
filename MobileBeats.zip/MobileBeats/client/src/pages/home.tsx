import { useQuery } from "@tanstack/react-query";
import { Heart, Download } from "lucide-react";
import Header from "@/components/layout/header";
import TrackItem from "@/components/music/track-item";
import AlbumCard from "@/components/music/album-card";
import PlaylistItem from "@/components/music/playlist-item";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { type SongWithDetails, type Playlist } from "@shared/schema";

export default function Home() {
  const { data: recentSongs, isLoading: recentLoading } = useQuery<SongWithDetails[]>({
    queryKey: ["/api/songs/recently-played"],
  });

  const { data: trendingSongs, isLoading: trendingLoading } = useQuery<SongWithDetails[]>({
    queryKey: ["/api/songs/trending"],
  });

  const { data: playlists, isLoading: playlistsLoading } = useQuery<Playlist[]>({
    queryKey: ["/api/playlists"],
  });

  return (
    <div className="min-h-screen">
      <Header />
      
      <main className="px-4 pb-32">
        {/* Recently Played Section */}
        <section className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold">Recently Played</h2>
            <Button variant="ghost" className="text-accent text-sm font-medium" data-testid="button-see-all-recent">
              See all
            </Button>
          </div>
          
          <div className="flex space-x-4 overflow-x-auto scroll-hide pb-2">
            {recentLoading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="flex-shrink-0">
                  <Skeleton className="w-32 h-32 rounded-lg" />
                  <Skeleton className="h-4 w-24 mt-2" />
                  <Skeleton className="h-3 w-20 mt-1" />
                </div>
              ))
            ) : (
              recentSongs?.slice(0, 3).map((song) => (
                <div key={song.id} className="flex-shrink-0">
                  <img 
                    src={song.imageUrl || song.album?.imageUrl} 
                    alt={`${song.title} Album`}
                    className="w-32 h-32 rounded-lg object-cover album-glow cursor-pointer" 
                    data-testid={`img-recent-song-${song.id}`}
                  />
                  <p className="text-sm font-medium mt-2 w-32 truncate" data-testid={`text-recent-title-${song.id}`}>
                    {song.title}
                  </p>
                  <p className="text-xs text-muted-foreground truncate" data-testid={`text-recent-artist-${song.id}`}>
                    {song.artist.name}
                  </p>
                </div>
              ))
            )}
          </div>
        </section>

        {/* Quick Actions */}
        <section className="mb-8">
          <div className="grid grid-cols-2 gap-3">
            <Button 
              variant="ghost"
              className="bg-card rounded-lg p-4 flex items-center space-x-3 hover:bg-secondary transition-colors h-auto justify-start"
              data-testid="button-liked-songs"
            >
              <div className="w-10 h-10 bg-primary/20 rounded-lg flex items-center justify-center">
                <Heart className="text-primary h-5 w-5" />
              </div>
              <span className="font-medium">Liked Songs</span>
            </Button>
            
            <Button 
              variant="ghost"
              className="bg-card rounded-lg p-4 flex items-center space-x-3 hover:bg-secondary transition-colors h-auto justify-start"
              data-testid="button-downloads"
            >
              <div className="w-10 h-10 bg-accent/20 rounded-lg flex items-center justify-center">
                <Download className="text-accent h-5 w-5" />
              </div>
              <span className="font-medium">Downloads</span>
            </Button>
          </div>
        </section>

        {/* Made For You */}
        <section className="mb-8">
          <h2 className="text-lg font-semibold mb-4">Made For You</h2>
          
          <div className="space-y-3">
            {playlistsLoading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="flex items-center space-x-3 bg-card rounded-lg p-3">
                  <Skeleton className="w-12 h-12 rounded-lg" />
                  <div className="flex-1">
                    <Skeleton className="h-4 w-32 mb-1" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                </div>
              ))
            ) : (
              playlists?.map((playlist) => (
                <TrackItem
                  key={playlist.id}
                  song={{
                    id: playlist.id,
                    title: playlist.name,
                    artist: { name: playlist.description || "Playlist" } as any,
                    imageUrl: playlist.imageUrl,
                  } as any}
                  showEqualizer={playlist.id === "playlist-1"}
                />
              ))
            )}
          </div>
        </section>

        {/* Trending Now */}
        <section className="mb-8">
          <h2 className="text-lg font-semibold mb-4">Trending Now</h2>
          
          <div className="grid grid-cols-2 gap-4">
            {trendingLoading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="bg-card rounded-lg p-4">
                  <Skeleton className="w-full aspect-square rounded-lg mb-3" />
                  <Skeleton className="h-4 w-20 mb-1" />
                  <Skeleton className="h-3 w-16 mb-2" />
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-3 w-12" />
                    <Skeleton className="h-4 w-4 rounded" />
                  </div>
                </div>
              ))
            ) : (
              trendingSongs?.slice(0, 4).map((song) => (
                <AlbumCard
                  key={song.id}
                  album={{
                    id: song.id,
                    title: song.title,
                    artist: song.artist,
                    imageUrl: song.imageUrl || song.album?.imageUrl || "",
                  } as any}
                  showPlayCount
                  playCount={song.playCount || 0}
                  onLike={() => {}}
                />
              ))
            )}
          </div>
        </section>

        {/* Your Library */}
        <section>
          <h2 className="text-lg font-semibold mb-4">Your Library</h2>
          
          <div className="space-y-2">
            {playlistsLoading ? (
              Array.from({ length: 2 }).map((_, i) => (
                <div key={i} className="flex items-center space-x-3 p-2 rounded-lg">
                  <Skeleton className="w-12 h-12 rounded-lg" />
                  <div className="flex-1">
                    <Skeleton className="h-4 w-32 mb-1" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                  <Skeleton className="h-4 w-4" />
                </div>
              ))
            ) : (
              playlists?.slice(0, 2).map((playlist) => (
                <PlaylistItem
                  key={playlist.id}
                  playlist={playlist}
                  onPlay={() => {}}
                  onMore={() => {}}
                />
              ))
            )}
          </div>
        </section>
      </main>
    </div>
  );
}
