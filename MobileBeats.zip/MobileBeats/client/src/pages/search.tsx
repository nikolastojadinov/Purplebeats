import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import TrackItem from "@/components/music/track-item";
import { Skeleton } from "@/components/ui/skeleton";
import { type SongWithDetails } from "@shared/schema";

export default function Search() {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: searchResults, isLoading } = useQuery<SongWithDetails[]>({
    queryKey: ["/api/songs/search", { q: searchQuery }],
    enabled: searchQuery.length > 0,
  });

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  return (
    <div className="min-h-screen">
      <Header onSearch={handleSearch} />
      
      <main className="px-4 pb-32">
        {searchQuery ? (
          <section>
            <h2 className="text-lg font-semibold mb-4">
              Search results for "{searchQuery}"
            </h2>
            
            {isLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="flex items-center space-x-3 bg-card rounded-lg p-3">
                    <Skeleton className="w-12 h-12 rounded-lg" />
                    <div className="flex-1">
                      <Skeleton className="h-4 w-32 mb-1" />
                      <Skeleton className="h-3 w-24" />
                    </div>
                    <Skeleton className="h-8 w-8 rounded" />
                  </div>
                ))}
              </div>
            ) : searchResults && searchResults.length > 0 ? (
              <div className="space-y-3">
                {searchResults.map((song) => (
                  <TrackItem
                    key={song.id}
                    song={song}
                    onLike={() => {}}
                    onMore={() => {}}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground" data-testid="text-no-results">
                  No results found for "{searchQuery}"
                </p>
              </div>
            )}
          </section>
        ) : (
          <section>
            <h2 className="text-lg font-semibold mb-4">Popular Searches</h2>
            <div className="grid grid-cols-2 gap-3">
              {["Electronic", "Hip Hop", "Indie Rock", "Pop", "Jazz", "Classical"].map((genre) => (
                <button
                  key={genre}
                  onClick={() => handleSearch(genre)}
                  className="bg-card rounded-lg p-4 text-left hover:bg-secondary transition-colors"
                  data-testid={`button-genre-${genre.toLowerCase().replace(' ', '-')}`}
                >
                  <span className="font-medium">{genre}</span>
                </button>
              ))}
            </div>
          </section>
        )}
      </main>
    </div>
  );
}
