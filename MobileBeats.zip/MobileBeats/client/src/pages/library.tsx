import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import PlaylistItem from "@/components/music/playlist-item";
import TrackItem from "@/components/music/track-item";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus } from "lucide-react";
import { type Playlist, type SongWithDetails } from "@shared/schema";

export default function Library() {
  const { data: playlists, isLoading: playlistsLoading } = useQuery<Playlist[]>({
    queryKey: ["/api/playlists"],
  });

  const { data: likedSongs, isLoading: likedLoading } = useQuery<SongWithDetails[]>({
    queryKey: ["/api/liked-songs"],
  });

  return (
    <div className="min-h-screen">
      <Header showSearch={false} />
      
      <main className="px-4 pb-32">
        {/* Header Actions */}
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-bold">Your Library</h1>
          <Button 
            variant="ghost"
            size="sm"
            className="text-primary"
            data-testid="button-create-playlist"
          >
            <Plus className="h-5 w-5 mr-2" />
            New Playlist
          </Button>
        </div>

        {/* Recently Added */}
        <section className="mb-8">
          <h2 className="text-lg font-semibold mb-4">Recently Added</h2>
          
          {playlistsLoading ? (
            <div className="space-y-2">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="flex items-center space-x-3 p-2 rounded-lg">
                  <Skeleton className="w-12 h-12 rounded-lg" />
                  <div className="flex-1">
                    <Skeleton className="h-4 w-32 mb-1" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                  <Skeleton className="h-4 w-4" />
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-2">
              {playlists?.map((playlist) => (
                <PlaylistItem
                  key={playlist.id}
                  playlist={playlist}
                  onPlay={() => {}}
                  onMore={() => {}}
                />
              ))}
            </div>
          )}
        </section>

        {/* Liked Songs */}
        <section className="mb-8">
          <h2 className="text-lg font-semibold mb-4">Liked Songs</h2>
          
          {likedLoading ? (
            <div className="space-y-3">
              {Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="flex items-center space-x-3 bg-card rounded-lg p-3">
                  <Skeleton className="w-12 h-12 rounded-lg" />
                  <div className="flex-1">
                    <Skeleton className="h-4 w-32 mb-1" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                  <Skeleton className="h-8 w-8 rounded" />
                </div>
              ))}
            </div>
          ) : likedSongs && likedSongs.length > 0 ? (
            <div className="space-y-3">
              {likedSongs.map((song) => (
                <TrackItem
                  key={song.id}
                  song={song}
                  onLike={() => {}}
                  onMore={() => {}}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground mb-4" data-testid="text-no-liked-songs">
                No liked songs yet
              </p>
              <Button 
                variant="outline"
                data-testid="button-discover-music"
              >
                Discover Music
              </Button>
            </div>
          )}
        </section>

        {/* Downloaded */}
        <section>
          <h2 className="text-lg font-semibold mb-4">Downloaded</h2>
          
          <div className="text-center py-12">
            <p className="text-muted-foreground mb-4" data-testid="text-no-downloads">
              No downloaded music
            </p>
            <Button 
              variant="outline"
              data-testid="button-browse-music"
            >
              Browse Music
            </Button>
          </div>
        </section>
      </main>
    </div>
  );
}
