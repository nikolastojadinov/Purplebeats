import { Play, Pause, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useMusicPlayer } from "@/hooks/use-music-player";
import { Progress } from "@/components/ui/progress";

export default function NowPlayingBar() {
  const { state, pauseSong, resumeSong } = useMusicPlayer();

  if (!state.currentSong) return null;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = state.duration > 0 ? (state.currentTime / state.duration) * 100 : 0;

  return (
    <div className="fixed bottom-20 left-0 right-0 px-4 z-30">
      <div className="max-w-md mx-auto bg-card/95 backdrop-blur-lg rounded-xl p-3 border border-border/50 shadow-2xl">
        <div className="flex items-center space-x-3">
          <img 
            src={state.currentSong.imageUrl || state.currentSong.album?.imageUrl} 
            alt={`Now Playing - ${state.currentSong.title}`}
            className="w-12 h-12 rounded-lg object-cover animate-spin-slow" 
          />
          <div className="flex-1 min-w-0">
            <p className="font-medium truncate" data-testid="text-current-song-title">
              {state.currentSong.title}
            </p>
            <p className="text-sm text-muted-foreground truncate" data-testid="text-current-artist">
              {state.currentSong.artist.name}
            </p>
          </div>
          <div className="flex items-center space-x-1">
            <Button 
              variant="ghost" 
              size="sm"
              className="p-2 text-muted-foreground hover:text-foreground transition-colors"
              data-testid="button-like-current"
            >
              <Heart className="h-4 w-4" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={state.isPlaying ? pauseSong : resumeSong}
              className="p-2 text-foreground hover:text-accent transition-colors"
              data-testid="button-play-pause"
            >
              {state.isPlaying ? (
                <Pause className="h-4 w-4" />
              ) : (
                <Play className="h-4 w-4" />
              )}
            </Button>
          </div>
        </div>
        
        <div className="mt-3">
          <Progress value={progress} className="w-full h-1" />
          <div className="flex justify-between text-xs text-muted-foreground mt-1">
            <span data-testid="text-current-time">{formatTime(state.currentTime)}</span>
            <span data-testid="text-duration">{formatTime(state.duration)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
