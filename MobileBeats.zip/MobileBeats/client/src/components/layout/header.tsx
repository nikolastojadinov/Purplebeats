import { Search, User } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

interface HeaderProps {
  onSearch?: (query: string) => void;
  showSearch?: boolean;
}

export default function Header({ onSearch, showSearch = true }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSearch && searchQuery.trim()) {
      onSearch(searchQuery.trim());
    }
  };

  return (
    <header className="px-4 pt-12 pb-4 bg-background/90 backdrop-blur-sm sticky top-0 z-40">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-full music-gradient flex items-center justify-center">
            <i className="fas fa-music text-white text-sm"></i>
          </div>
          <h1 className="text-xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            PurpleBeats
          </h1>
        </div>
        <Button 
          variant="ghost" 
          size="sm" 
          className="p-2 rounded-full bg-card hover:bg-secondary transition-colors"
          data-testid="button-user-profile"
        >
          <User className="h-4 w-4 text-muted-foreground" />
        </Button>
      </div>
      
      {showSearch && (
        <form onSubmit={handleSearchSubmit} className="relative">
          <input 
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search songs, artists, albums..."
            className="w-full bg-card border border-border rounded-full px-4 py-3 pl-12 text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            data-testid="input-search"
          />
          <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
        </form>
      )}
    </header>
  );
}
