import { useMusicPlayer } from "@/contexts/music-player-context";

export { useMusicPlayer };
