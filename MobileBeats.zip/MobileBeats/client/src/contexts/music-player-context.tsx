import { createContext, useContext, useState, ReactNode } from "react";
import { type SongWithDetails } from "@shared/schema";

interface MusicPlayerState {
  currentSong: SongWithDetails | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  queue: SongWithDetails[];
  currentIndex: number;
}

interface MusicPlayerContextType {
  state: MusicPlayerState;
  playSong: (song: SongWithDetails, queue?: SongWithDetails[]) => void;
  pauseSong: () => void;
  resumeSong: () => void;
  nextSong: () => void;
  previousSong: () => void;
  setVolume: (volume: number) => void;
  setCurrentTime: (time: number) => void;
  addToQueue: (song: SongWithDetails) => void;
  removeFromQueue: (index: number) => void;
}

const MusicPlayerContext = createContext<MusicPlayerContextType | undefined>(undefined);

export function MusicPlayerProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<MusicPlayerState>({
    currentSong: null,
    isPlaying: false,
    currentTime: 0,
    duration: 0,
    volume: 80,
    queue: [],
    currentIndex: 0,
  });

  const playSong = (song: SongWithDetails, queue: SongWithDetails[] = []) => {
    const newQueue = queue.length > 0 ? queue : [song];
    const index = newQueue.findIndex(s => s.id === song.id);
    
    setState(prev => ({
      ...prev,
      currentSong: song,
      isPlaying: true,
      queue: newQueue,
      currentIndex: index >= 0 ? index : 0,
      currentTime: 0,
      duration: song.duration,
    }));
  };

  const pauseSong = () => {
    setState(prev => ({ ...prev, isPlaying: false }));
  };

  const resumeSong = () => {
    setState(prev => ({ ...prev, isPlaying: true }));
  };

  const nextSong = () => {
    setState(prev => {
      const nextIndex = prev.currentIndex + 1;
      if (nextIndex < prev.queue.length) {
        const nextSong = prev.queue[nextIndex];
        return {
          ...prev,
          currentSong: nextSong,
          currentIndex: nextIndex,
          currentTime: 0,
          duration: nextSong.duration,
          isPlaying: true,
        };
      }
      return prev;
    });
  };

  const previousSong = () => {
    setState(prev => {
      const prevIndex = prev.currentIndex - 1;
      if (prevIndex >= 0) {
        const prevSong = prev.queue[prevIndex];
        return {
          ...prev,
          currentSong: prevSong,
          currentIndex: prevIndex,
          currentTime: 0,
          duration: prevSong.duration,
          isPlaying: true,
        };
      }
      return prev;
    });
  };

  const setVolume = (volume: number) => {
    setState(prev => ({ ...prev, volume }));
  };

  const setCurrentTime = (currentTime: number) => {
    setState(prev => ({ ...prev, currentTime }));
  };

  const addToQueue = (song: SongWithDetails) => {
    setState(prev => ({
      ...prev,
      queue: [...prev.queue, song],
    }));
  };

  const removeFromQueue = (index: number) => {
    setState(prev => {
      const newQueue = prev.queue.filter((_, i) => i !== index);
      let newCurrentIndex = prev.currentIndex;
      
      if (index < prev.currentIndex) {
        newCurrentIndex = prev.currentIndex - 1;
      } else if (index === prev.currentIndex) {
        // If we're removing the current song, play the next one
        if (newQueue.length > 0) {
          const nextIndex = Math.min(newCurrentIndex, newQueue.length - 1);
          const nextSong = newQueue[nextIndex];
          return {
            ...prev,
            queue: newQueue,
            currentSong: nextSong,
            currentIndex: nextIndex,
            currentTime: 0,
            duration: nextSong.duration,
          };
        } else {
          return {
            ...prev,
            queue: newQueue,
            currentSong: null,
            currentIndex: 0,
            isPlaying: false,
          };
        }
      }
      
      return {
        ...prev,
        queue: newQueue,
        currentIndex: newCurrentIndex,
      };
    });
  };

  const value: MusicPlayerContextType = {
    state,
    playSong,
    pauseSong,
    resumeSong,
    nextSong,
    previousSong,
    setVolume,
    setCurrentTime,
    addToQueue,
    removeFromQueue,
  };

  return (
    <MusicPlayerContext.Provider value={value}>
      {children}
    </MusicPlayerContext.Provider>
  );
}

export function useMusicPlayer() {
  const context = useContext(MusicPlayerContext);
  if (context === undefined) {
    throw new Error("useMusicPlayer must be used within a MusicPlayerProvider");
  }
  return context;
}
